document.addEventListener("DOMContentLoaded", function () {
    const signupForm = document.getElementById("signup");
    const loginForm = document.getElementById("login");
    const entryForm = document.getElementById("entryForm");
    const entriesContainer = document.getElementById("entriesContainer");
    const authSection = document.getElementById("authSection");
    const memoryDiarySection = document.getElementById("memoryDiarySection");
    const logoutBtn = document.getElementById("logoutBtn");

    // Check if user is already logged in
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentUser) {
        showMemoryDiary(currentUser);
    }

    // Sign-Up
    signupForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const username = document.getElementById("signupUsername").value;
        const password = document.getElementById("signupPassword").value;

        const users = JSON.parse(localStorage.getItem("users")) || [];

        // Check if username already exists
        if (users.some(user => user.username === username)) {
            alert("Username already exists. Please choose a different one.");
            return;
        }

        // Save new user
        users.push({ username, password });
        localStorage.setItem("users", JSON.stringify(users));

        alert("Sign-up successful! Please log in.");
        signupForm.reset();
    });

    // Login
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const username = document.getElementById("loginUsername").value;
        const password = document.getElementById("loginPassword").value;

        const users = JSON.parse(localStorage.getItem("users")) || [];

        const user = users.find(u => u.username === username && u.password === password);

        if (user) {
            localStorage.setItem("currentUser", JSON.stringify(user));
            showMemoryDiary(user);
        } else {
            alert("Invalid username or password.");
        }

        loginForm.reset();
    });

    // Show Memory Diary
    function showMemoryDiary(user) {
        authSection.style.display = "none";
        memoryDiarySection.style.display = "block";
        loadEntries(user.username);

        // Log out button
        logoutBtn.addEventListener("click", function () {
            localStorage.removeItem("currentUser");
            authSection.style.display = "block";
            memoryDiarySection.style.display = "none";
        });
    }

    // Save memory entry
    entryForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const entryDate = document.getElementById("entryDate").value;
        const entryTitle = document.getElementById("entryTitle").value;
        const entryText = document.getElementById("entryText").value;
        const entryTags = document.getElementById("entryTags").value.split(',').map(tag => tag.trim());
        const entryMood = document.getElementById("entryMood").value;

        const currentUser = JSON.parse(localStorage.getItem("currentUser"));
        const username = currentUser.username;

        const newEntry = {
            date: entryDate,
            title: entryTitle,
            text: entryText,
            tags: entryTags,
            mood: entryMood,
        };

        let entries = JSON.parse(localStorage.getItem(username)) || [];
        entries.push(newEntry);
        localStorage.setItem(username, JSON.stringify(entries));

        loadEntries(username);
    });

    // Load memories for the current user
    function
